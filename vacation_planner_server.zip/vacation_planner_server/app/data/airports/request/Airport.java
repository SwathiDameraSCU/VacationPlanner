package data.airports.request;

/**
 * Created by kanikaagrawal on 2/6/16.
 */
public class Airport
{
    public String code;
    public String name;
    public String city;
    public String country;
    public String timezone;
    public Float lat;
    public Float lng;
}
