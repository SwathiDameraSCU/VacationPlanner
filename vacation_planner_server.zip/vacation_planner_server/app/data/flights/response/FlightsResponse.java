package data.flights.response;


/**
 * Created by kanikaagrawal on 2/21/16.
 */
public class FlightsResponse
{
    public Trips trips;
}
